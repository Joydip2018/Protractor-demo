//import the class
import { browser, element, by, protractor, $$, $ } from 'protractor';
import { IdentificationType, BasePage } from "../Base/BasePage";

const Locators = {
    
    heading: {
        type:IdentificationType[IdentificationType.Xpath],
        value: "//div[@class='hero-headline no-toc']"
    },

    Features: {
        type:IdentificationType[IdentificationType.Xpath],
        value:"//span[contains(text(),'Features')]"
    },
}

export class HomePage extends BasePage {

    //Get Element                           
    heading = this.ElementLocator(Locators.heading);
    Features = this.ElementLocator(Locators.Features);
    Featuretext= element(by.xpath("//h1[@id='features--benefits']"));

    //Open browser
    async OpenBrowser(url: string){
        await browser.get(url);
        await browser.manage().window().maximize();
    }
    
    //verify heading
    async GetHeading(){
        await this.heading.getText().then((text) => {
            console.log("The heading is :" + text);
            expect(text).toBeDefined("One framework. Mobile & desktop.");
        });
    }

    //click on HTML tutorial
    async ClickFeatures(){
        await this.Features.click();
    }

}

