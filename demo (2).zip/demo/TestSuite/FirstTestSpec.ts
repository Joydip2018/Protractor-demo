import { browser, element, by, protractor, $$, $ } from 'protractor';
import { HomePage } from "../pages/HomePage";

describe("Going to write first test", () => {
    //Globally
    var homePage = new HomePage();

    it("Verify Heading", async () => {

        //Open browser
        await homePage.OpenBrowser("https://angular.io/");

        //Get the heading
        await homePage.GetHeading();
       
    });
    it("Verify Feature page", async () => {

         //Click the Features
         await homePage.ClickFeatures();
         //Verify Feature page
         await homePage.Featuretext.getText().then((text) => {
            console.log("The heading is :" + text);
            expect(text).toBeDefined("Features & Benefits");
         });
    });
});
