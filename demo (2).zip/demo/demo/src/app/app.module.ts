import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Component } from '@angular/core';


import { AppComponent } from './app.component';
import { InnerpageComponent } from './innerpage/innerpage.component';
import { ListpageComponent } from './listpage/listpage.component';
import { ReadzoneService } from './Services/readzone.service';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule,Routes } from '@angular/router'; 
import { FormsModule } from '@angular/forms';
import { EditdeletepageComponent } from './editdeletepage/editdeletepage.component';
import { FormsComponent } from './forms/forms.component';


const routes:Routes=[
{path: '', redirectTo: '/listpage', pathMatch: 'full'},
{path:'addnew',component:InnerpageComponent},
{path:'listpage',component:ListpageComponent},
{path:'FormsComponent',component:FormsComponent},
{path:'Editdeletepage',component:EditdeletepageComponent},
];

@NgModule({
  declarations: [
    AppComponent,
    InnerpageComponent,
    ListpageComponent,
    EditdeletepageComponent,
    FormsComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    RouterModule.forRoot(routes),
  ],
  providers: [ReadzoneService],
  bootstrap: [AppComponent]
})
export class AppModule { }
