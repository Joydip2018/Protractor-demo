import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditdeletepageComponent } from './editdeletepage.component';

describe('EditdeletepageComponent', () => {
  let component: EditdeletepageComponent;
  let fixture: ComponentFixture<EditdeletepageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditdeletepageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditdeletepageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
