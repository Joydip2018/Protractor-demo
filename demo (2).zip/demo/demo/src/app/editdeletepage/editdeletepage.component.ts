import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ReadzoneService } from '../Services/readzone.service';

@Component({
  selector: 'app-editdeletepage',
  templateUrl: './editdeletepage.component.html',
  styleUrls: ['./editdeletepage.component.css']
})
export class EditdeletepageComponent implements OnInit {
  zonename: string;
  Listdata: Object;
  constructor(private Readzone: ReadzoneService, private route: ActivatedRoute) {}
  instances = ['Instance 1', 'Instance 2', 'Instance 3'];
  Zoneread(){
    this.route.queryParams.subscribe(params => {
      console.log(params);
      this.zonename = params['id'];
      console.log(this.zonename);

      this.Readzone.getzone(this.zonename).subscribe((zonedata) => {
        console.log(zonedata);
        this.Listdata = zonedata;
      });
    })
  }
  ngOnInit() {
    this.Zoneread();
  }

  
  
}
