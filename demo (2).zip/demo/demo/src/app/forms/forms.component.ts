import { Component, OnInit } from '@angular/core';
import {Userdetails} from './userdetails';
import { FormserviceService } from '../Services/formservice.service';

@Component({
  selector: 'app-forms',
  templateUrl: './forms.component.html',
  styleUrls: ['./forms.component.css']
})
export class FormsComponent implements OnInit {

  topics = ['Angular', 'java', 'node'];
  topichaserror = true;
  useModel = new Userdetails('Joydip','joydip@gmail.com',9863158406,'default','morning',true);
  constructor(private formservice: FormserviceService ) { }

  validateTopic(value)
  {
    if(value==='default')
    {
      this.topichaserror=true;
    }
    else
    {
      this.topichaserror=false;
    }
  }
  onSubmit()
  {
    this.formservice.enroll(this.useModel).subscribe(
      data =>console.log('success',data),
      error=>console.log('Error!', error)
      
    )
    console.log(this.useModel);
  }

  ngOnInit() {
  }

}
