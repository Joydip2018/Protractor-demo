export class Userdetails {
    constructor(
        public name: string,
        public email: string,
        public phone: Number,
        public topic: string,
        public timeslot: string,
        public sendmail: Boolean,
        )
    {}
}
