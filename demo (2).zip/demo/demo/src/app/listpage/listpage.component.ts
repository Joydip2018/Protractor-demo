import { Component, OnInit } from '@angular/core';
import { ReadzoneService } from '../Services/readzone.service';


@Component({
  selector: 'app-listpage',
  templateUrl: './listpage.component.html',
  styleUrls: ['./listpage.component.css']
})
export class ListpageComponent implements OnInit {

  Listdata: Object;
  constructor(private Readzone: ReadzoneService) { }

  ngOnInit() {
    this.Readzone.getzonelist().subscribe((zonedata) => {
      console.log("joy"+zonedata);
      this.Listdata = zonedata;
    });
  }
  delete = function (Zone_Name: any) {
    this.Readzone.deletezone(Zone_Name).subscribe((zonedata: { data: any; }) => {
      alert(zonedata.data);
      this.ngOnInit();
    }, (error: any) => this.errorMessage = error)
  }   
}
