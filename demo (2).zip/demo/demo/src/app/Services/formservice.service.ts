import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { Userdetails } from '../forms/userdetails';

@Injectable()
export class FormserviceService {

  constructor(private http:HttpClient) { }

  url='';
  enroll(user: Userdetails)
  {
    return this.http.post<any>(this.url, user)
  }
}
