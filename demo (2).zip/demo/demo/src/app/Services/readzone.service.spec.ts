import { TestBed, inject } from '@angular/core/testing';

import { ReadzoneService } from './readzone.service';

describe('ReadzoneService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ReadzoneService]
    });
  });

  it('should be created', inject([ReadzoneService], (service: ReadzoneService) => {
    expect(service).toBeTruthy();
  }));
});
