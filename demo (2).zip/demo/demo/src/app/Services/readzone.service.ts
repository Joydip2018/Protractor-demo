import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable()
export class ReadzoneService {
  public httpOptions : any;
  constructor(private http:HttpClient) 
  { }
  getzonelist()
  {
    return this.http.get("http://localhost:3000/api/view");
  }
  getzone(name: any)
  {
    return this.http.get("http://localhost:3000/api/view/"+name);
  }
  addzone(zoneobj: any)
  {
    console.log("Test",zoneobj);
    return this.http.post("http://localhost:3000/api/addnew",zoneobj,this.httpOptions);
  }
  deletezone(name: any){   
    console.log("Test",name);
    return this.http.delete("http://localhost:3000/api/delete/"+name);
  }
}
