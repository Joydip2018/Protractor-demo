import { Component, OnInit } from '@angular/core';
import { ReadzoneService } from '../Services/readzone.service';

@Component({
  selector: 'app-innerpage',
  templateUrl: './innerpage.component.html',
  styleUrls: ['./innerpage.component.css']
})
export class InnerpageComponent implements OnInit {
  public postData: any;
  constructor(private Readzone:ReadzoneService ) 
  { }
  valbutton ="Save";
  /* onSave= function(zonedata: any)
  {
    console.log(this.zonedata);
  } */
onSave = function(zonedata: any) 
  {    
     //console.log(Instance,Zone_Name,Country_Base_Type,Backroom_Location,Trading_Days);
     this.Readzone.addzone(zonedata)
     .subscribe((zonedata: { data: any; }) =>  {
      this.postData = zonedata; 
      console.log(this.postData);
      //alert(zonedata.data);  
     }   
     , (error: any) => this.errorMessage = error )     
   }
  ngOnInit() 
  {
    //console.log("joydip",zonedata);
  }
}
