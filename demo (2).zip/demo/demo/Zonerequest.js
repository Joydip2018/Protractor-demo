const express = require("express");
const router = express.Router();

// Schema = Model
const Zone = require("./ZoneJSONReader");

// all routes here
router.get("/view", (req, res) => {
  // Mongoose Schema methods.
  Zone.find((err, empData) => {
    if (err) {
      console.log(err);
    }
    res.send(empData);
  });
});

router.get("/view/:name", (req, res) => {
  // Mongoose Schema methods.
  console.log(req.params.Zone_Name);
  Zone.find({ "Zone_Name": req.params.name }, (err, empData) => {
    if (err) {
      console.log(err);
    }
    res.send(empData);
  });
});

router.post("/addnew", (req, res) => {
  let newZone = new Zone({
    Instance: req.body.Instance,
    Zone_Name: req.body.Zone_Name,
    Country_Base_Type: req.body.Country_Base_Type,
    Backroom_Location: req.body.Backroom_Location,
    Trading_Days: req.body.Trading_Days,
  });

  newZone.save((err, empdata) => {
    if (err) {
      res.status(404).send("Failed to add Zone");
    } else {
      res.send("Zone added");
    }
  });
});

router.delete("/delete/:name", (req, res) => {
  Zone.remove({ Zone_Name: req.params.name }, (err, result) => {
    if (err) {
      res.status(404).send("Failed to delete Zone");
    } else {
      res.send("Zone deleted");
    }
  });
});

module.exports = router;