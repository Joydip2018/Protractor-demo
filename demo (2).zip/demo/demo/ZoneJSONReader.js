const mongoose = require("mongoose");

console.log("DB connected");
const ZoneSchema = mongoose.Schema({
    Instance:
    {
        type: String,
        requied: true
    },
    Zone_Name:
    {
        type: String,
        requied: true
    },
    Country_Base_Type:
    {
        type: String,
        requied: true
    },
    Backroom_Location:
    {
        type: String,
        requied: true
    },
    Trading_Days:
    {
        type: String,
        requied: true
    },},
    { versionKey: false }
);

// mapping the collection inside the MongoDB => ZoneSchema
var Zones = mongoose.model("zone", ZoneSchema);
console.log("ZoneSchema connected");
module.exports = Zones;